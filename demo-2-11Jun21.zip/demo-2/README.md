# Neo4j

connectivity to Neo4j graphical database from browser.

<hr />

## Documentation

### Development

- install dependancies and run web server

  ```bash
  npm install
  # AND
  npm run dev
  ```

### Deployment

- create build from source code and serve file over http

  ```bash
  npm run build
  ```
