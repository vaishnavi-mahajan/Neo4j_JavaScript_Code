import axios from "axios";

export default class Neo4j {
  constructor(options) {
    this.options = options;
    this.axios = axios.create({
      baseURL: this.baseURL(),
      "Access-Control-Allow-Origin": "*",
      headers: {
        ...this.authHeaders(),
      },
    });
  }
  baseURL() {
    return `http://${this.options.host}:${this.options.port}/db/${this.options.db}`;
  }
  authHeaders() {
    return {
      Authorization: `Basic ${btoa(
        `${this.options.user}:${this.options.pass}`
      )}`,
    };
  }
  async get(query, params = {}, fetchMode = ["row", "graph"]) {
    const res = await this.axios.post(
      "/tx/commit",
      {
        statements: [
          {
            statement: query,
            parameters: params,
            resultDataContents: fetchMode,
          },
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );
    return res.data;
  }
}
