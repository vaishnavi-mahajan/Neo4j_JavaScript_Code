export default class TreeGraph extends EventTarget {
  //global constants
  MAXZOOM = 2;
  MINZOOM = 0.05;

  options = {
    zoom: 1,
    zoomRation: 0.05,
  };

  // construct graph
  constructor(selector) {
    super();
    this.$selector = selector;
    this.$elem = $(selector);
    this.insertZoomInOutWidget();
  }

  // create nasted treenode
  toTree(nodes) {
    console.log(nodes);
    return $("<ul/>", {
      class: "active",
    }).append(
      nodes.map((node) =>
        $("<li/>").append([
          $("<div />", { class: "arrow-down" }),
          $("<div />", { class: "relation-label" }).text("Child"),
          $("<a />", {
            href: "javascript:void(0);",
            node: JSON.stringify(node),
            title: node.title
          })
            .css({
              "background-color": node.color || "#ffffff",
              color:  "#000000",
            })
            .append(
              $("<div />", { class: "node-preview" }).append(
                $("<div />", { class: "node-details p-1" }).text(node.name)).append(
                  $("<div />", { class: "node-details-other-label p-1" }).html(node.node.Allocated_Budget !=undefined ? `Allocated Budget : <span class="allocated-budget">${node.node.Allocated_Budget}</span>` : "Allocated Budget : <span id='parent-allocated-budget'>0</span>")).append(
                    $("<div />", { class: "node-details-other-label p-1" }).html(node.node.Reserved_Budget!=undefined ? `Reserved Budget : <span class="reserved-budget">${node.node.Reserved_Budget}</span>` : "Reserved Budget : <span id='parent-reserved-budget'>0</span>")
                  )
            )
            .on(
              "click",
              () => (
                (this.$node = node),
                this.dispatchEvent(new Event("node.clicked"))
              )
            ),
          ...((node.children || []).length ? this.toTree(node.children) : []),
        ])
      )
    );
  }

  //append or replace zoom component
  insertZoomInOutWidget() {
    this.$zoomout = $("<button />", {
      class: "btn border zoom-in",
      title: "Zoom In",
    })
      .append($("<i />", { class: "fa fa-search-plus" }))
      .on("click", () => {
        if (this.options.zoom < this.MAXZOOM) {
          this.options.zoom =
            Math.round(
              (this.options.zoom + this.options.zoomRation + Number.EPSILON) *
              100
            ) / 100;
          this.setZoom();
        }
      });
    this.$zoomin = $("<button />", {
      class: "btn border zoom-out",
      title: "Zoom Out",
    })
      .append($("<i />", { class: "fa fa-search-minus" }))
      .on("click", () => {
        if (this.options.zoom > this.MINZOOM) {
          this.options.zoom =
            Math.round(
              (this.options.zoom - this.options.zoomRation + Number.EPSILON) *
              100
            ) / 100;
          this.setZoom();
        }
      });
    const elem = $("<div />", {
      class: "btn-group zoom-container",
    }).append([this.$zoomout, this.$zoomin]);
    this.$elem.parent().parent().find(".zoom-container").replaceWith(elem);
  }

  /**
   * set zoom level and update zoom buttons based on level
   */
  setZoom() {
    this.$zoomout.removeAttr("disabled");
    this.$zoomin.removeAttr("disabled");
    console.log(
      this.options.zoom === this.MAXZOOM,
      this.options.zoom,
      this.MAXZOOM,
      this.MINZOOM
    );
    if (this.options.zoom === this.MAXZOOM) {
      this.$zoomout.attr("disabled", "disabled");
    }
    if (this.options.zoom === this.MINZOOM) {
      this.$zoomin.attr("disabled", "disabled");
    }
    this.$elem.css("zoom", this.options.zoom);
  }

  // clear graph area
  clear() {
    this.$elem.find("ul").remove();
  }

  expandNode($li) {
    var children = $li.find("> ul");
    children.show("fast").addClass("active");
  }

  //rander graph data with new options and remount all events
  render(options) {
    console.log(options);
    const $this = this;
    this.options = Object.assign(this.options, options);
    this.$nodes = this.options.data.map((node) => this.toTree([node]));
    this.clear();
    this.$elem.append(this.$nodes);
    // trigger new events
    this.expandAllNode();

    //populate parent allocated budget
    const first_allocated_budget = $(".allocated-budget:first").html();

    if(first_allocated_budget !=undefined){
      $("#parent-allocated-budget").html(first_allocated_budget);
    }

    //populate parent reserved budget
    const first_reserved_budget = $(".reserved-budget:first").html();
    if(first_reserved_budget !=undefined){
      $("#parent-reserved-budget").html(first_reserved_budget);
    }

    

    
    $(`${this.$selector} > ul > li > a`).bind("contextmenu", function (e) {
      $this.$event = e;
      $this.$target = $(this).parent();
      e.stopPropagation();
      $this.dispatchEvent(new Event("contextmenu"));
      return false;
    });
  }

  // toggle higlight based on search key word
  toggleHighLight($anchor, searchTerm) {
    const $nodeText = $anchor.find(".node-details");
    const $node = JSON.parse($anchor.attr("node") || "{}");
    if ($node.node && $node.node.name) {
      const exist = $node.node.name
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
      if (exist) {
        $anchor.addClass("filtered-node");
        $nodeText.html(
          `${(($node.node && $node.node.name) || "").replace(
            searchTerm,
            `<span class="highlighted-text">${searchTerm}</span>`
          )}`
        );
      } else {
        $nodeText.html(`${$node.node && $node.node.name}`);
        $anchor.removeClass("filtered-node");
      }
    } else {
      $nodeText.html(`${$node.node && $node.node.name}`);
      $anchor.removeClass("filtered-node");
    }
  }

  // loop through all node with certain call-back
  loopThroughAllNodes(cb, ...params) {
    $(`${this.$selector} > ul > li`).each((i, e) => {
      const $li = $(e).find("ul > li");
      cb.bind(this)($li.find("a"), ...params);
      $li.find("ul > li").each((i, e) => {
        const $li = $(e).find("ul > li");
        cb.bind(this)($li.find("a"), ...params);
      });
    });
  }

  // expand all nodes
  expandAllNode() {
    $(`${this.$selector} li > ul`).show("fast").addClass("active");
  }

  // collapse All Nodes
  collapseAllNodes() {
    return $(`${this.$selector} li > ul`).hide("fast").removeClass("active");
  }

  // update node background
  updateNodeBackgroud($anchor, hasColors, prop) {
    const $node = JSON.parse($anchor.attr("node") || "{}");
    if ($node.node && $node.node[prop]) {
      const backgroundColor = hasColors[$node.node[prop]] || "#ffffff";
      $anchor.css({
        "background-color": backgroundColor,
        color: this.invertColor(backgroundColor),
      });
    } else {
      $anchor.css({
        "background-color": "#ffffff",
        color: this.invertColor("#ffffff"),
      });
    }
  }

  // invert cilir for background text color
  invertColor(hexTripletColor) {
    var color = hexTripletColor;
    color = color.substring(1);
    color = parseInt(color, 16);
    color = 0xffffff ^ color;
    color = color.toString(16);
    color = ("000000" + color).slice(-6);
    color = "#" + color;
    return color;
  }
}
