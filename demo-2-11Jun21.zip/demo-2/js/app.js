import Neo4j from "./neo4j";
import TreeGraph from "./tree-graph";
import colors from "./colors";

// Neo4j Constants
const Neo4jHost = "localhost";
const Neo4jPort = 7474;
const Neo4jUser = "neo4j";
const Neo4jPass = "admin#123";
const Neo4jDb = "neo4j";

// containers
const $main = $("main");
const $canvas = $("#canvas");

// Pace settings
//default settings
// Pace.options.ajax.trackMethods = ["GET"];
Pace.options.ajax.trackMethods = ["POST"];

const neo4j = new Neo4j({
  host: Neo4jHost,
  port: Neo4jPort,
  user: Neo4jUser,
  pass: Neo4jPass,
  db: Neo4jDb,
});

const NODES = {
  Planning_Item_Parent_Name: "Planning_Item_Parent_Name",
  Item_Name: "Item_Name",
  Item_Name_without_parent: "Item_Name_without_parent",
};

const allPlanningLevelTypes = {};

const graph = new TreeGraph("#canvas");
// node clicked event listner
graph.addEventListener("node.clicked", function (e) {
  const props = e.target.$node.node;
  $("#node-properties").html(
    Object.keys(props).map((prop) =>
      $("<li />", {
        class: "list-group-item",
      }).append(
        $("<div />", {
          class: "input-group",
        }).append([
          $("<div />", {
            class: "input-group-prepend",
            title: prop,
          }).append(
            $("<div />", { class: "input-group-text" }).html(
              `${
                prop.length > 20 ? `${prop.substring(0, 20)}...` : prop
              }:- &nbsp;`
            )
          ),
          $("<input />", {
            class: "form-control color-picker",
            title: props[prop],
            value: props[prop],
            readonly: true,
          }),
        ])
      )
    )
  );
  $("#collapse-properties").collapse("show");
});

//collapse event
graph.addEventListener("contextmenu", function (e) {
  const $event = e.target.$event;
  const $li = e.target.$target;
  const $children = $li.find("> ul");
  const $anchor = $li.find("a");
  const $node = JSON.parse($anchor.attr("node") || "{}");
  if ($children.is(":visible")) {
    $children.hide("fast").removeClass("active");
  } else {
    const node = $("#search-input").data("node");
    drawTree((node && node.type) || null, node && node.value, true);
  }
});

$("#toolbar-expand-all").on("click", function () {
  const node = $("#search-input").data("node");
  drawTree((node && node.type) || null, node && node.value, true);
});

$("#toolbar-collpase-all").on("click", function () {
  graph.collapseAllNodes();
});

$(document.body).ready(function () {
  // JQuery auto-complete
  $("#search-input").autocomplete({
    source: function (req, res) {
      const query = `MATCH (n)  WHERE n.name CONTAINS $search RETURN n.name, labels(n)[0]`;
      neo4j
        .get(query, { search: req.term }, ["row"])
        .then((data) => {
          const rows = data.results[0].data;
          res(
            rows.map((item) => ({
              value: item.row[0],
              label:
                "Planning_Item_Parent_Name" == item.row[1]
                  ? ""
                  : `${item.row[0]}`,
              type: item.row[1],
            }))
          );
        })
        .catch((err) => {
          res([]);
        });
    },
    select: function (event, ui) {
      const item = ui.item;
      $(this).data("node", item);
    },
    minLength: 1,
  });

  getAllPlanningLevelTypes();
  drawTree();

 
});

async function getAllPlanningLevelTypes() {
  const query = `MATCH (n) WHERE EXISTS(n.Planning_Level_Type) RETURN DISTINCT "node" as entity, n.Planning_Level_Type AS Planning_Level_Type LIMIT 25 UNION ALL MATCH ()-[r]-() WHERE EXISTS(r.Planning_Level_Type) RETURN DISTINCT "relationship" AS entity, r.Planning_Level_Type AS Planning_Level_Type`;

  const res = await neo4j.get(query);
  for (const [i, type] of res.results[0].data.entries()) {
    allPlanningLevelTypes[type.row[1]] = colors[i];
  }
}

async function drawTree(node = null, search = null, withRelation = false) {
  // query with mapping to relations
  let query = "";
  if (search) {
    if (withRelation) {
      if (node === NODES.Planning_Item_Parent_Name) {
        query = `MATCH (a:Planning_Item_Parent_Name {name: $search})-[]->(m) WITH  a, collect(m) AS children RETURN a, labels(a)[0], children LIMIT 1`;
      } else if (node === NODES.Item_Name_without_parent) {
        query = `MATCH (a:Item_Name_without_parent {name: $search}) WITH a RETURN a, labels(a)[0] LIMIT 1`;
      } else if (node === NODES.Item_Name) {
        query = `MATCH (a)-[]->(m:Item_Name {name: $search}) WITH  a, collect(m) AS children RETURN a, labels(a)[0], children LIMIT 1`;
      } else {
        query = `MATCH (a{name: $search})-[]->(m) WITH a, collect(m) AS children RETURN a, labels(a)[0], children LIMIT 1`;
      }
    } else {
      query = `MATCH (a {name: $search}) RETURN a, labels(a)[0] LIMIT 1`;
    }
  } else {
    query = `MATCH (a)-[]->(m) WITH  a, collect(m) AS children RETURN a, labels(a)[0], children SKIP 3 LIMIT 1`;
  }

  // params
  const params = {
    // limit: 25
    search,
  };

  let data = {};

  // query neo4j database and fetch the data
  try {
    data = await neo4j.get(query, params);
  } catch (err) {
    console.log(err);
    throw new Error(`Something went wrong!.`);
  }

  if (data.errors.length) {
    throw new Error(`${data.errors[0].message}`);
  }

  const rows = data.results[0].data;

   //Populate first node name in URL
   const first_node_name = rows[0].row[0].name;
   if (first_node_name) {
     window.history.replaceState(null, null, "#" + first_node_name);
   }

  const hasColor = allPlanningLevelTypes;

  // rander tree graph with new data
  graph.render({
    data: rows.map((i) => ({
      name: i.row[0].name,
      node: i.row[0],
      type: i.row[1],
      title: "Right Click to Expand/Collapse",
      color: hasColor[i.row[0].Planning_Level_Type] || "#C0E8D5",
      children: (i.row[2] || []).map((c, i) => ({
        name: c.name,
        node: c,
        color: hasColor[c.Planning_Level_Type] || null,
      })),
    })),
  });
}

$("#search-form").submit(handleSearchSubmit);

//This function is called on clicking search button
function handleSearchSubmit(e) {
  e.preventDefault();
  const searchTerm = $("#search-input").val();
  const node = $("#search-input").data("node");
  // draw tree with node name
  drawTree((node && node.type) || null, searchTerm, true);
  var href = window.location.href;
  if (href.includes("#")) {
    href = href.split("#")[0];
  }

  //To update the searched item in URL
  if (searchTerm) {
    console.log("yes search term");
    window.history.replaceState(null, null, `#search=${searchTerm}`);
  } else {
    const first_node_name = $("#node-details:first").html();
    if (first_node_name) {
      window.history.replaceState(null, null, "#" + first_node_name);
    }
  }
}
